class Feedback < ApplicationRecord
  belongs_to :branch
end
