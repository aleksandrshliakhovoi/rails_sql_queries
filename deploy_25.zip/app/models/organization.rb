class Organization < ApplicationRecord
  has_many :branches
end
