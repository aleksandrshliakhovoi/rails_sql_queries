Rails.application.routes.draw do
  root 'dashboard#index'
end
